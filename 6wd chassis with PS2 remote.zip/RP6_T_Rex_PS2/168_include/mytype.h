#ifndef _MYTYPE_H_
#define _MYTYPE_H_

//#define CONST const

#define uchar  unsigned char
#define uint   unsigned int
#define usint   unsigned int
#define ulong  unsigned long



#define UINT8X  unsigned char
#define UINT8   unsigned char
#define UINT16X unsigned int
#define UINT16  unsigned int
#define UINT32X unsgined long
#define UINT32  unsigned long 

#define INT8X   char
#define INT8    char 
#define INT16X  int
#define INT16   int
#define INT32X  long
#define INT32   long 




#endif
